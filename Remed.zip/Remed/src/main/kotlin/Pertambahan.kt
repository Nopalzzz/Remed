package remed

fun main (){
    //Buat rumus pertambahan, pengurangan, perkalian dan pembagian
    val pertambahan = 321+992
    val pengurangan = 322-228
    val perkalian = 12*7
    val pembagian = 90/3

    println(pertambahan)
    println(pengurangan)
    println(perkalian)
    println(pembagian)
}