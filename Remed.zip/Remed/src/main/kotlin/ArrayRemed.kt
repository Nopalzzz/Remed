package remed

fun main() {
//buat contoh aray min.20 lalu print
    val namaorang: Array<String> = arrayOf(
        "Nopal",
        "Hanif",
        "Ilyas",
        "Ardan",
        "Sidiq",
        "Toro",
        "Asih",
        "Mumu",
        "Kholis",
        "Dewi",
        "Agus Lapar",
        "Reja",
        "Okto Kesepian",
        "Hermawan",
        "Parwoto",
        "Liyyana",
        "Sigit",
        "Hepi",
        "Yono",
        "Ipin")
    namaorang.forEachIndexed{index,namaorang->
        println("$namaorang")
    }

}